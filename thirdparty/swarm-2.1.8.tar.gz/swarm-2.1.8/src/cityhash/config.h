/* config.h for cityhash */
